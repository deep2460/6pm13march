const router=require('express').Router()//router module
const Emp=require('../models/emp')//call table file on router
const student=require('../models/student')
const Reg=require('../models/reg')
function handlelogin(req,res,next){
    if(req.session.isAuth){
        next()
    }else{
        res.redirect('/login')
    }
}

let multer=require('multer')//module
const nodemailer=require('nodemailer')
let storage=multer.diskStorage({
    destination:function(req,file,cb){
        cb(null,'./public/upload')
    },
    filename:function(req,file,cb){
        cb(null,Date.now()+file.originalname)
    }
})//method
let upload=multer({
    storage:storage,
    limits:{fileSize:4*1024*1024}//in bytes
})

router.get('/',(req,res)=>{
    res.render("home.ejs")
})
router.get('/about',(req,res)=>{
    res.render("about.ejs")
})
router.get('/test',(req,res)=>{
    res.render("test.ejs")
})
router.get('/form',(req,res)=>{
    res.render('form.ejs')
})
router.post('/form',(req,res)=>{
    console.log(req.body)
})
router.get('/form2',(req,res)=>{
    res.render('form2.ejs')
})
router.post('/form2',(req,res)=>{
    console.log(req.body)
})
router.get('/tt/:name',(req,res)=>{
    console.log(req.params.name)
})
router.get('/data',(req,res)=>{
    let array=[{name:'deepak',address:'jaipur',email:'deepakdhaked21@gmail.com'},
               {name:'anoop',address:'jaipur',email:'dhaked.anoop@gmail.com'},
               {name:'xyz',address:'delhi',email:'xyz@gmail'}]
    res.render('data.ejs',{array})
})
router.get('/emp',(req,res)=>{
    res.render('empform.ejs')
})
router.post('/emp',upload.single('img'),(req,res)=>{
    const filename=req.file.filename//console.log(filename)
    const {ename,edept,sal,dob,image}=req.body
    const record=new Emp({name:ename,dept:edept,salary:sal,dob:dob,image:filename})
    //console.log(record)
    record.save()//save in DB
    res.redirect('/empdata')
})
router.get('/empdata',handlelogin,async(req,res)=>{
    const emprecords=await Emp.find()//method find all data array+object
    //console.log(emprecords)
    res.render('empdata.ejs',{emprecords})
})
router.get('/empsingledata',async(req,res)=>{
    const empsinglerecord=await Emp.findOne()//single object only
    //console.log(empsinglerecord)
    res.render('empsingledata.ejs',{empsinglerecord})
})
router.get('/delete/:abc',async(req,res)=>{
    const id=req.params.abc
    //console.log(id)
    await Emp.findByIdAndDelete(id)
    res.redirect('/empdata')
})
router.get('/update/:xyz',async(req,res)=>{
    const id=req.params.xyz
    //console.log(id)
    const emprecord=await Emp.findById(id)
    res.render('empupdateform.ejs',{emprecord})
})
router.post('/update/:xyz',async(req,res)=>{
    const empid=req.params.xyz
    //console.log(empid)
    const {ename,edept,sal}=req.body
    const updaterecord=await Emp.findByIdAndUpdate(empid,{name:ename,dept:edept,salary:sal})
    //console.log(updaterecord)
    res.redirect('/empdata')
})
router.get('/mail',(req,res)=>{
    res.render('mailform.ejs')
})
router.post('/mail',upload.single('attatchment'),async(req,res)=>{
    const path=req.file.path
    const {emailto,emailfrom,subject,body}=req.body
    let transporter = nodemailer.createTransport({
        host: "smtp.gmail.com",
        port: 587,
        secure: false, // true for 465, false for other ports
        auth: {
          user: 'deepdd4148@gmail.com', // generated ethereal user
          pass: 'fezkbfuxsokragfv', // generated ethereal password
        },
      });
      //console.log('connected to gmail smtp server')
      let info = await transporter.sendMail({
        from: emailfrom, // sender address
        to: emailto, // list of receivers
        subject: subject, // Subject line
        text: body, // plain text body
        //html: "<table border='1'><tr><th>first name</th><th>last name</th></tr><tr><td>deepak</td><td>dhaked</td></tr></table>", // html body
        attachments:[{
            path:path
        }]
    });
      //console.log('email sent')
})


router.get('/sendmail',async(req,res)=>{
    
})
router.get('/signup',(req,res)=>{
    res.render('signup.ejs')
})
router.post('/signup',async(req,res)=>{//console.log(req.body)
    const {uname,pass}=req.body
    const usercheck=await Reg.findOne({username:uname})//console.log(usercheck)
    if(usercheck==null){
        const record=new Reg({username:uname,password:pass})
        record.save()
    }else{
        res.send('username already taken')
    }
})
router.get('/login',(req,res)=>{
    res.render('login.ejs')
})
router.post('/login',async(req,res)=>{
    //console.log(req.body)
    const {uname,pass}=req.body
    const record=await Reg.findOne({username:uname})
    //console.log(record)
    if(record!==null){
        if(record.password==pass){
            req.session.isAuth=true//trigger of session
            res.redirect('/empdata')
        }else{
            res.send('incorrect password')
        }
    }else{
        res.send('incorrect username')
    }
})
router.get('/logout',(req,res)=>{
    req.session.destroy=false
    res.redirect('/login')
})




router.get('/student',(req,res)=>{
    res.render('studentform.ejs')
})
router.post('/student',upload.single('stimg'),(req,res)=>{
    const stfilename=req.file.filename
    const {stname,stclass,stmarks,dob,image}=req.body
    const stRecord=new student({ name:stname,class:stclass,totalmarks:stmarks,dob:dob,image:stfilename})
    stRecord.save()
    res.redirect('/stdata')
    
})
router.get('/stdata',async(req,res)=>{
    const stdata=await student.find()
    //console.log(stdata)
    res.render('studentdata.ejs',{stdata})
})
router.get('/stsingledata',async(req,res)=>{
    const stsingledata=await student.findOne()
    //console.log(stsingledata)
    res.render('studentsingledata.ejs',{stsingledata})
})
router.get('/stdelete/:aaa',async(req,res)=>{
    const stId=req.params.aaa
    //console.log(stId)
    await student.findByIdAndDelete(stId)
    res.redirect('/stdata')
})
router.get('/stupdate/:bbb',async(req,res)=>{
    const stid=req.params.bbb
    //console.log(stid)
    const stupdate=await student.findById(stid)
    res.render('studentupdateform.ejs',{stupdate})
})
router.post('/stupdate/:bbb',async(req,res)=>{
    const stid=req.params.bbb
    //console.log(stid)
    const {stname,stclass,stmarks}=req.body
    const updaterecord=await student.findByIdAndUpdate(stid,{name:stname,class:stclass,totalmarks:stmarks})
    //console.log(updaterecord)
    res.redirect('/stdata')
})



module.exports=router//make global