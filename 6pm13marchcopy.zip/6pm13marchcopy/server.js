const http=require('http')//module inbuilt node
const fs=require('fs')
const homefile=fs.readFileSync('./home.html')
const stylesheet=fs.readFileSync('./style.css')
const img=fs.readFileSync('./media/instagram-icon.png')
//console.log(homefile)

const server=http.createServer((req,res)=>{
    if(req.url==='/'){
        res.write(homefile)
        res.end()
    }else if(req.url==='/contacts'){
        res.end("welcome to contact page")
    }else if(req.url==='/gallary'){
        res.end("welcome to gallary")
    }else if(req.url==='/style.css'){
        res.write(stylesheet)
        res.end()
    }else if(req.url==='/media/instagram-icon.png'){
        res.write(img)
        res.end()
    }else{
        res.end("404 page not found")
    }
})//method

server.listen(5000)