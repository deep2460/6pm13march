const express=require('express')//function formet
const app=express()//module
app.use(express.urlencoded({extended:false}))
const abcRouter=require('./routers/abc')//call router file
const mongoose=require('mongoose')//module
const session=require('express-session')//module
mongoose.connect('mongodb://127.0.0.1:27017/facebookdb')//db connect method mongoose





app.use(session({secret:'deep',resave:false,saveUninitialized:false}))
app.use(abcRouter)//refrence abcRouter
app.use(express.static('public'))
app.set('view engine','ejs')
app.listen(5000,()=>{console.log('server is running on port 5000')})