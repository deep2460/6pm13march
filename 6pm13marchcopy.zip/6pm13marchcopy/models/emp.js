const { default: mongoose } = require('mongoose')
const moongoose=require('mongoose')

const empSchema=mongoose.Schema({
    name:String,
    dept:String,
    salary:Number,
    dob:Date,
    image:String
})


module.exports=mongoose.model('emp',empSchema)//table created