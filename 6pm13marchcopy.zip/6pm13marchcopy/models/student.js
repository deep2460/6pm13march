const mongoose=require('mongoose')//module

const studentSchema=mongoose.Schema({
    name:String,
    class:Number,
    totalmarks:Number,
    dob:Date,
    image:String
})//schema created method



module.exports=mongoose.model('student',studentSchema)//table created method